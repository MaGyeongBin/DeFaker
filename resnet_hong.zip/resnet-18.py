import os
import cv2
import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import models, transforms
from torch.utils.data import Dataset, DataLoader, random_split
from tqdm import tqdm

# 폴더 내 모든 mp4 파일을 탐색하는 함수
def get_video_paths(folder_path):
    video_paths = []
    for root, _, files in os.walk(folder_path):
        for file in files:
            if file.endswith('.mp4'):
                video_paths.append(os.path.join(root, file))
    return video_paths

# 데이터셋 클래스 정의
class VideoDataset(Dataset):
    def __init__(self, video_paths, labels, transform=None):
        self.video_paths = video_paths
        self.labels = labels
        self.transform = transform

    def __len__(self):
        return len(self.video_paths)

    def __getitem__(self, idx):
        video_path = self.video_paths[idx]
        label = self.labels[idx]

        # mp4 영상에서 첫 번째 프레임 읽기
        cap = cv2.VideoCapture(video_path)
        ret, frame = cap.read()
        cap.release()

        if not ret:
            raise ValueError(f"Cannot read video: {video_path}")

        # OpenCV는 BGR로 읽으므로 RGB로 변환
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        if self.transform:
            frame = self.transform(frame)

        return frame, label

# 데이터 전처리 설정
transform = transforms.Compose([
    transforms.ToPILImage(),
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])

# 진짜와 딥페이크 영상 경로
real_videos_folder = r"D:\deepfake dataset\original_sequences\actors\c40\videos"
fake_videos_folder = r"D:\deepfake dataset\manipulated_sequences\DeepFakeDetection\c40\videos"

# 폴더에서 모든 mp4 파일 경로 가져오기
real_video_paths = get_video_paths(real_videos_folder)
fake_video_paths = get_video_paths(fake_videos_folder)

# 경로와 레이블 결합
video_paths = real_video_paths + fake_video_paths
labels = [0] * len(real_video_paths) + [1] * len(fake_video_paths)  # 0: 진짜, 1: 딥페이크

# 데이터셋 생성
dataset = VideoDataset(video_paths, labels, transform=transform)

# 데이터셋 분할 (90% 훈련, 10% 검증)
train_size = int(0.9 * len(dataset))
val_size = len(dataset) - train_size
train_dataset, val_dataset = random_split(dataset, [train_size, val_size])

# 데이터로더 생성
train_loader = DataLoader(train_dataset, batch_size=4, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=4, shuffle=False)

# ResNet-18 모델 로드 및 수정
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = models.resnet18(pretrained=True)
model.fc = nn.Linear(model.fc.in_features, 2)  # 출력 클래스를 2개로 수정
model = model.to(device)

# 손실 함수와 옵티마이저 설정
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 학습 및 검증 루프
num_epochs = 5
for epoch in range(num_epochs):
    model.train()
    running_loss = 0.0
    for inputs, labels in tqdm(train_loader, desc=f"Epoch {epoch+1}/{num_epochs} [Training]"):
        inputs, labels = inputs.to(device), labels.to(device)
        
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        running_loss += loss.item()

    print(f"Epoch {epoch+1}/{num_epochs}, Training Loss: {running_loss/len(train_loader)}")
    
    # 검증 루프
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for inputs, labels in tqdm(val_loader, desc=f"Epoch {epoch+1}/{num_epochs} [Validation]"):
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
    
    val_accuracy = correct / total * 100
    print(f"Epoch {epoch+1}/{num_epochs}, Validation Accuracy: {val_accuracy:.2f}%")

print("Training Complete.")